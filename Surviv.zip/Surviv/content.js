alert("Stop Hacking Surviv.io It's kills the game !! ")
alert("For Restart Playing Surviv.io please delete this Extension AND STOP HACK SURVIV.IO !!!!")
document.location.href="http://google.com";
